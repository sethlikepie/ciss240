#include <iostream>

int main() {
    int result = 12345 % 0;
    std::cout << "The result of 0 % 12345 is: " << result << std::endl;
    return 0;
}
