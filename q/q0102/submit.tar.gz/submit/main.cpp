#include <iostream>
  
int main()
{
    std::cout << "2b or not 2b";

    return 0;
}
