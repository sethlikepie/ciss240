// Name: Seth Thurman
// File: main.cpp

#include <iostream>

int main()
{
    std::cout << "hello master ...\n";

    return 0;
}
