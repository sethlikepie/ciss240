#include <iostream>

int main()
{
    std::cout << "1\n2\n3\n";

    return 0;
}
