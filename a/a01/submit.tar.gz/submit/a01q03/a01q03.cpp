// File: a01q03.cpp
// Name: Seth Thurman

#include <iostream>

int main()
{
    std::cout << " d   4      3\n"
              << "-- 3x  = 12x\n"
              << "dx\n";

    return 0;
}
