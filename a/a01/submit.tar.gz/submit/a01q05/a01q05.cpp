// File: a01q05.cpp
// Name: Seth Thurman

#include <iostream>

int main()
{
    std::cout << "#include <iostream>\n"
              << "int main()\n"
              << "{\n"
              << "    std::cout << \"Hello, world!\\n\";\n"
              << "    return 0;\n"
              << "}\n";

    return 0;
}
