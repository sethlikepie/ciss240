// File: a01q01.cpp
// Name: Seth Thurman

#include <iostream>

int main()
{
    std::cout << "tic-tac-toe\n"
              << "by GameWorld\n"
              << "  0 1 2\n"
              << " +-----+\n"
              << "0| | |O|0\n"
              << " |-+-+-|\n"
              << "1|X| | |1\n"
              << " |-+-+-|\n"
              << "2| | | |2\n"
              << " +-----+\n"
              << "  0 1 2\n"
              << "X's turn. Please enter row and column:\n";

    return 0;
}
